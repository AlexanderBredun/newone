"use strict";

const
    gulp = require("gulp"),
    htmlmin = require('gulp-htmlmin'),
    sass = require("gulp-sass"),
    cssnano = require('gulp-cssnano'),
    bulkSass = require("gulp-sass-bulk-import"),
    sourcemaps = require("gulp-sourcemaps"),
    autoprefixer = require("gulp-autoprefixer"),
    imagemin = require("gulp-imagemin"),
    browserSync = require("browser-sync").create(),
    svgmin = require("gulp-svgmin"),
    svgSprite = require("gulp-svg-sprite"),
    del = require("del"),
    gulpif = require('gulp-if'),
    argv = require('yargs').argv,
    newer = require('gulp-newer'),
    imgSrc = 'dev/images/*.*',
    imgDest = 'build/images';

gulp.task("sass", () =>
    gulp
        .src("dev/sass/**/*.scss")
        .pipe(gulpif((!argv.prod), sourcemaps.init() ))
        .pipe(bulkSass())
        .pipe(
            sass({
                outputStyle: "compact",
                includePaths: ["./sass"]
            }).on("error", sass.logError)
        )
        .pipe(
            autoprefixer({
                browsers: ["last 7 versions"],
                cascade: false
            })
        )
        .pipe(gulpif(argv.prod, cssnano(), sourcemaps.write("../maps") ))
        .pipe(gulp.dest("build/css"))
        .on("end", browserSync.reload)
);

gulp.task("imagemin", () =>
    gulp
        .src(imgSrc)
        .pipe(newer(imgDest))
        .pipe(
            imagemin([
                imagemin.gifsicle({ interlaced: true }),
                imagemin.jpegtran({ progressive: true }),
                imagemin.svgo({
                    plugins: [{ removeViewBox: true }, { cleanupIDs: false }]
                })
            ])
        )
        .pipe(gulp.dest(imgDest))
        .on("end", browserSync.reload)
);

gulp.task("html", () =>
    gulp
        .src("dev/*.html", {since: gulp.lastRun('html')})
        .pipe(gulpif(argv.prod, htmlmin({ collapseWhitespace: true }) ))
        .pipe(gulp.dest("build"))
        .on("end", browserSync.reload)
);

gulp.task("scripts", () =>
    gulp
        .src(["dev/js/*.js"])
        .pipe(sourcemaps.init() )
        .pipe(gulpif((!argv.prod), sourcemaps.init() ))
        /*.pipe(newer('build/js/all.min.js'))
        .pipe(concat("all.min.js"))
        .pipe(gulpif(argv.prod, uglify(), sourcemaps.write("../maps") ))*/
        .pipe(gulp.dest("build/js"))
        .on("end", browserSync.reload)
);

gulp.task("svg", () =>
    gulp
        .src("dev/images/svgSprite/*.svg")
        .pipe(
            svgmin({
                js2svg: {
                    pretty: true
                }
            })
        )
        .pipe(
            svgSprite({
                mode: {
                    symbol: {
                        sprite: "sprite.svg"
                    }
                }
            })
        )
        .pipe(gulp.dest("build/images/"))
);

gulp.task("serve", function() {
    browserSync.init({
        server: {
            baseDir: "build"
        }
    });
});

gulp.task("watch", function() {
    gulp.watch("dev/sass/**/*.scss", gulp.series("sass"));
    gulp.watch("dev/images/svgSprite/*.svg", gulp.series("svg"));
    gulp.watch("dev/*.html", gulp.series("html"));
    gulp.watch("dev/js/**/*.*", gulp.series("scripts"));
});

gulp.task("copy", () =>
    gulp
        .src(["dev/fonts/*.*", "dev/чай Tess. Чай в пирамидках. чай Тесс_files/*.*"], {
            base: "dev"
        })
        .pipe(gulp.dest("build"))
);

gulp.task("clean", () =>
    //del("build")
    del(['build'], { force: true })
);

gulp.task("build", gulp.series(
    "clean",
    gulp.parallel("copy", "html", "sass", "scripts", "imagemin", "svg")
));

gulp.task("default",
    gulp.series(
        //'clean',
        gulp.parallel("watch", "serve")
    )
);
