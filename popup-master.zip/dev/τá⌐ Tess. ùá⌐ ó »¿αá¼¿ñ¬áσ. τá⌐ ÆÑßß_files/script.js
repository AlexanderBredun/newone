function social_open (url) {
    window.open(url,'','toolbar=0,status=0,width=626,height=436');
}

function setPagination(){
    $(".pagination").each(function(){
        var $this = $(this);
        $this.css('width', $("li", $this).length*25);
    });
}

function isEven(n) {
    return n % 2 == 0;
}

jQuery(function () {

    var fadeinObject = function(bottom_of_window, top_of_object, $this) {
        /* If the object is completely visible in the window, fade it in */
        if (bottom_of_window > top_of_object) {
            var $liList = $this.find('li');
            var len = $liList.length;
            var i;
            for (i = 0; i < 5; i++) {
                $liList.eq(i).delay(i * 500).animate({'opacity': 1}, 500);
            }
            for (i = 5; i < len; i++) {
                $liList.eq(i).css('opacity','1');
            }
        }
    };
    
    var setscrollvisible = function (){		
        var $window = $(window);
        var bottom_of_window = $window.scrollTop();
        if( bottom_of_window > 800 ) {
            /* If the object is completely visible in the window, fade it in */
            $('.animationblock').each(function () {
                $(this).css('opacity', '1');
                $(this).animate('margin-top', '0');
            });
            $('.animationblocklist').each(function () {
                fadeinObject($window.scrollTop(), 800, $(this));
            });
        }
    };
    
    /**
     * 
     * @param x integer
     */
    var hideAllTexts = function (x) {
        $('html, body').animate({scrollTop: x}, 2000);
        $(".top-list-elem").removeClass("active");
        //прячем все тексты
        $(".listcontainer").hide();
        $(".subline").hide();
    
    };

    var moveSliderLock = false;
    var unlockMoveSlider = function () {
        moveSliderLock = false;
    };

    var moveSlider = function ( $section, pos ) {
        if ( moveSliderLock ) {
            return;
        }
        var curPos = parseInt( $section.data("curpos"), 10) || 0;
        var difference = Math.abs(curPos - pos);
        if ( difference == 0 ) {
            return;
        }

        var windowwidth = $( window ).width();
        if(windowwidth>1024){
            difference = 1.5*difference;
            moveSliderLock = true;
            setTimeout(unlockMoveSlider, difference*1000);
        }else{
            difference = 0.75*difference;
            moveSliderLock = true;
            setTimeout(unlockMoveSlider, difference*750);
        }

        // сразу запомним новую позицию
        $section.data("curpos", pos);
        //Достаем ширину
        var w = $(".slidercontainer", $section).width();
        //вычисляем позицию слайдера
        var finalpos = pos * w;
        var $products = $(".products", $section);
        $products.css("transition-duration", difference+"s");
        var aux = "translate3d(-" + finalpos + "px, 0px, 0px)";


        //двигаем слайдер
        $products.css(browserCssTransformProperty, aux);
        //проводим манипуляции с точками, присваивая нужную выделеную позицию
        var $points = $("i", $section.find(".circlesblock"));
        $points.removeClass("fa-circle").addClass("fa-circle-o");
        $points.eq(pos).removeClass("fa-circle-o").addClass("fa-circle");
    };


    var generatePagePoints = function ( $ul, wrapperClass, divider ) {
        var quantity, i, $liList, $wrapper, $block, $pagePoints;
        
        $liList = $("li", $ul);
        
        quantity = $liList.length;
        
        if ( divider > 1 ) {
            quantity = Math.ceil(quantity/divider);
        }
        if ( quantity > 1 ) {
            // нам нужна постраничка и стрелочки
            $wrapper = $('<div class="slidercircleshover"><div class="circlesblock"></div></div>');
            $wrapper.addClass( wrapperClass );
            $block = $(".circlesblock", $wrapper);
            for ( i=0; i < quantity; i++ ) {
                $block.append('<i class="fa fa-circle-o" aria-hidden="true"></i>');
            }
            $pagePoints =$("i", $block);
            $pagePoints.first().removeClass("fa-circle-o").addClass("fa-circle");
            
            var $parent = $ul.closest(".whiteblockshadow");
            $wrapper.appendTo( $parent );
            $parent.append('<div class="previus"><img src="/local/templates/main/images/leftblack.png"></div>'+
                '<div class="next"><img src="/local/templates/main/images/rightblack.png"></div>');
            
            $pagePoints.each( function (index) {
                var $point = $(this);
                //клик на кружочек
                $point.on("click", function () {
                    if ( !$point.hasClass("fa-circle") ) {
                        moveSlider( $parent, index );
                    }
                })
            });
            
            $(".previus", $parent).on("click", function () {
                var $curPoint = $pagePoints.filter(".fa-circle");
                var index = $pagePoints.index( $curPoint );
                if ( index > 0 ) {
                    index--;
                } else {
                    index = $pagePoints.length - 1;
                }
                moveSlider( $parent, index );
            });
            $(".next", $parent).on("click", function () {
                var $curPoint = $pagePoints.filter(".fa-circle");
                var index = $pagePoints.index( $curPoint );
                if ( index == $pagePoints.length - 1 ) {
                    index = 0;
                } else {
                    index++;
                }
                moveSlider( $parent, index );
            });
            
        }
    };

    var removePagePoints = function ($ul) {
        var $parent = $ul.closest(".whiteblockshadow");
        $(".previus", $parent).off("click").remove();
        $(".next", $parent).off("click").remove();
        $("i.fa", $parent).off("click");
        $(".slidercircleshover", $parent).remove();
    };

    var oldDivider = 0;
    var catalogSectionInfo = [
        {
            elem: '#productslider',
            cssClass: 'productcircles'
        },
        {
            elem: '#product2slider',
            cssClass: 'product2circles'
        },
        {
            elem: '#product31slider',
            cssClass: 'product31circles'
        },
        {
            elem: '#product32slider',
            cssClass: 'product32circles'
        }
    ];

    var setCircles = function () {
        var divider, i, $itemList;
        // для подсчета ширины сгодится любой блок раздела. пусть будет первый
        var w = $(".porductslidercontainer").width();
        if (w > 767) {
            divider = 4;
        } else if (w > 500) {
            divider = 2;
        } else {
            divider = 1;
        }

        if ( oldDivider != divider ) {
            oldDivider = divider;
            for (i = 0; i < 4; i++) {
                $itemList = $(catalogSectionInfo[i]['elem']);
                removePagePoints( $itemList );
				if(i==3 && w >767){
					divider = 2;
				}
                generatePagePoints($itemList, catalogSectionInfo[i]['cssClass'], divider);
            }
        }
        
    };

    var lang = $("html").prop("lang");
    
    var pos2 = 0;
	var pos1 = 0;
	var pos31 = 0;
	var pos32 = 0;
    var $sections = $(".totalhoverblockproducts");
    
    var $osnovyaja = $sections.eq(0);
    var $piramidki = $sections.eq(1);
    var $podarok = $sections.eq(2);
	var $artof = $sections.eq(3);
    var $novosti = $("#news");
	var $art_of = $("#product32slider");
    var $historija = $("#art-of-composition");
    
    var $animationblock = $('.animationblock');
    var $animationblocklist = $('.animationblocklist');
    
    var maxpos1, maxpos2, maxpos31, maxpos32;

    var $ramka = $(".ramka");
    var $iframeInRamka = $ramka.find('iframe');
    var isFF = (navigator.userAgent.search("Firefox") > -1);
    
    var $body = $("body");
    var $face = $(".face");
    var $seredinacontaner = $(".seredinacontaner");
    var $paralaxcontaner = $(".paralaxcontaner");
    
    var setParallaxHeight = function (h) {
        $seredinacontaner.css("height",h);
        $paralaxcontaner.css("height",h);
    };
    var oldWindowOffset = -1000;
    
    var parallaxImageShift = function (n) {
        var x = n;
        return function () {
            var $this = $(this);
            var pixels = $this.data("top")+x;
            $this.css( "top", "" + pixels + "px" );
        }
    };
    
    function doParallax(){
        if ( oldWindowOffset != window.pageYOffset ) {
            oldWindowOffset = window.pageYOffset;
            $(".paralabackpart", $paralaxcontaner).each( parallaxImageShift( parseInt(window.pageYOffset/10, 10) ) );
            var positionY1 = parseInt(window.pageYOffset/7, 10);
            $(".paralabackpart", $seredinacontaner).each( parallaxImageShift( positionY1 ) );
            $body.css("background-position", "0 "+positionY1 + "px");
        }
    }
    
    var parallaxRun = function () {
        setParallaxHeight( $face.css("height") );
        $(".paralabackpart").each(function () {
            var $this = $(this);
            $this.data("top", parseInt( $this.css("top") ), 10 );
        });
        setInterval(doParallax, 50);
    };
    
    
    var browserCssTransformProperty;
    
    var detectTransformProperty = function( $elm )
    {
        if ( $elm.css("transform") !== undefined ) {
            browserCssTransformProperty = "transform";
            return;
        }
        if ( $elm.css("-webkit-transform") !== undefined ) {
            browserCssTransformProperty = "-webkit-transform";
            return;
        }
        if ( $elm.css("-ms-transform") !== undefined ) {
            browserCssTransformProperty = "-ms-transform";
            return;
        }
        if ( $elm.css("-o-transform") !== undefined ) {
            browserCssTransformProperty = "-o-transform";
        }
    };

    function getTransform(el) {
        //returns x,y,z,1
        var transform = el.css(browserCssTransformProperty);
        var results = transform.match(/matrix(?:(3d)\(-{0,1}\d+(?:, -{0,1}\d+)*(?:, (-{0,1}\d+))(?:, (-{0,1}\d+))(?:, (-{0,1}\d+)), -{0,1}\d+\)|\(-{0,1}\d+(?:, -{0,1}\d+)*(?:, (-{0,1}\d+))(?:, (-{0,1}\d+))\))/);

        if(!results) return [0, 0, 0];
        if(results[1] == '3d') return results.slice(2,5);

        results.push(0);
        return results.slice(5, 8); // returns the [X,Y,Z,1] values
    }

    window.onload = function () {
		if ( isFF ) {
			setTimeout(function () {
				$iframeInRamka.css("height",$ramka.height()*0.86+"px");
				$body.addClass("ff");
			},60);
		}
	}();

    $(".modile-open").click(function(){
        $(".menu-list").toggle('fold',{
            direction: 'right'
        },2000);
    });

    var $menuTopLinks = $('a.anclaspan');
    var $menuSecondLinks = $('a.ancla');
    var $menuMobileLinks = $('a.ancla2');
    // элементы верхнего меню
    var $topListElem = $(".top-list-elem");

    var tessMainPage = function () {

        // пусть обо что-нибудь задетектит
        detectTransformProperty( $novosti );


        setCircles();
        setTopSliderproduct1();
        setTopSliderproduct2();
        setTopSliderproduct31();
		setTopSliderproduct32();
        setPagination();
        setscrollvisible();
        $( window ).resize(  function () {
            setCircles();
            setTopSliderproduct1();
            setTopSliderproduct2();
            setTopSliderproduct31();
			setTopSliderproduct32();
			if ( isFF ) {
                var w=$( document ).width();
				if(w>500){
					$(".ramka").find('iframe').css("height",w*0.31665688+"px");
				}else{
					$(".ramka").find('iframe').css("height",w*0.33394425+"px");
				}
            }
        });
		
	if ( isFF ) {
		setTimeout(function () {
		var w=$( document ).width();
		if(w>500){
			$(".ramka").find('iframe').css("height",w*0.31665688+"px");
		}else{
			$(".ramka").find('iframe').css("height",w*0.33394425+"px");
		}
		$body.addClass("ff");
		},200);
	}

        $('.top-list-elem.logo').click(function (e) {
            e.preventDefault();
            hideAllTexts(0);
        });

        $(".mouse").animateSprite({
            fps: 6,
            animations: {
                walkRight: [0, 1, 2, 3, 4, 5],
                walkLeft: [3, 2, 1, 0]
            },
            loop: true,
            complete: function () {
                // use complete only when you set animations with 'loop: false'
                alert("animation End");
            }
        });
    
        var $third = $(".third");
        var $four = $(".four");
        var $five = $(".five");
    
        var topmenuColorer = function () {
            // этот кусок меняет состояние верхнего меню (помечает нужный пункт красным)
            var scroll = $( window ).scrollTop() + 77;
            var $target = undefined;
            if ( scroll >= $osnovyaja.offset().top ) {
                $target = $third;
            }
			if ( scroll >= $art_of.offset().top ) {
                $target = $five;
            }
            if ( scroll >= $novosti.offset().top ) {
                $target = $four;
            }
            /*if ( scroll >= $historija.offset().top ) {
                $target = $five;
            }*/
			
            
            // проводим манипуляции с классами только в том случае, когда что-то поменялось
            if ( $target == undefined ) {
                if ( $topListElem.hasClass("redactive") ) {
                    $topListElem.removeClass("redactive");
                }
            } else {
                if ( !$target.hasClass("redactive") ) {
                    $topListElem.removeClass("redactive");
                    $target.addClass("redactive");
                }
            }
        };
    
        var windowScrollHandler = function () {
            topmenuColorer();
            
            $animationblock.each( function(){
                var $this = $(this);
                if ( !$this.data("animationShow") ) {
                    var top_of_object = $this.offset().top + 220;
                    var bottom_of_window = $( window ).scrollTop() + $( window ).height();
                    // If the object is completely visible in the window, fade it in
                    if( bottom_of_window > top_of_object && $this.css("opacity") < 1 ){
                        $this.data("animationShow", true);
                        $this.animate({'opacity': 1},300);
                        $this.animate({'margin-top':0},{
                            queue: false,
                            duration: 400,
                            complete: function () {
                                $this.data("animationShow", false);
                            }
                        });
                    }
                }
            });

            $animationblocklist.each( function(){
                var $this = $(this);
                var top_of_object = $this.offset().top + 220;
                var bottom_of_window = $( window ).scrollTop() + $( window ).height();
                fadeinObject(bottom_of_window, top_of_object, $this);
            });

        };
        
        $( window ).on('scroll', $.throttle( 50, windowScrollHandler));

        /*-----------------------------------news opening---------------------------------*/

        var clickLocked = false;

        var itemFadeIn = function ( $elm ) {
            var $item = $elm;
            return function () {
                $item.animate({ opacity: 1 });
                $(".content", $item).animate({ opacity: 1 });
            }
        };

        var showPublication = function ( $item, $activator ) {
            $item.css("display","block");
            var $body = $("body");
            var topOffset = $activator.closest(".newsblock").offset().top - $("header").height();

            var curOffsetItem = parseInt( $item.css("top"), 10 ) || 0;
            var curOffsetBody = parseInt( $body.scrollTop(), 10 ) || 0;

            if ( topOffset != curOffsetItem || topOffset != curOffsetBody ) {
                $item.offset({top: topOffset, left: 0});
                $('html, body').animate({ scrollTop: topOffset }, 1000, itemFadeIn($item) );
            } else {
                itemFadeIn($item)();
            }

        };
        var showPublicationHandler = function(type){
            var pubType = type;
            return function () {
                if ( clickLocked ) {
                    // блокируем спамклик, так как непонятно, что делать
                    return false;
                }
                clickLocked = true;

                var $preview = $(this);
                var id = parseInt( $preview.data("id"), 10 ) || 0;
                if ( id > 0 ) {
                    var $detail = $( '#pubdetail' + id );
                    if ( !$detail.length ) {
                        // нужна подгрузка
                        var ajaxUrl = "/ajax/news.php";
                        if ( lang == "en" ) {
                            ajaxUrl = "/en" + ajaxUrl;
                        } else {
                            ajaxUrl = "/ru" + ajaxUrl;
                        }

                        $.ajax({
                            type: "POST",
                            cache: false,
                            url: ajaxUrl,
                            dataType: "html",
                            data: {id: id, type: pubType},
                            statusCode: {
                                404: function() {
                                    $preview.off("click");
                                }
                            },
                            error: function () {
                                $preview.off("click");
                                console.info("error happens");
                                console.error( arguments );
                            },
                            success: function( str ) {
                                $face.append( str );
                                $detail = $( '#pubdetail' + id );
                                showPublication( $detail, $preview );
                            }
                        })
                    } else {
                        showPublication( $detail, $preview );
                    }
                }
                clickLocked = false;
                return false;

            }
        };

        var closePublicationPopup = function(){
            $(this).parent().animate({opacity: 0},function(){
                $(".opennews").css("display","none");
            });
        };

        $face.on( "click", ".closenews", closePublicationPopup );
        $face.on( "click", ".getbacknews", closePublicationPopup );

        $(".newsbotton").on( "click", showPublicationHandler("news") );
        $(".historijabotton").on( "click", showPublicationHandler("history") );

        /*------------------------------------ socials -----------------------------------*/

        var socialShare = function (event) {
            event.preventDefault();

            var purl = window.location.href;
            var $product = $(this).parent().parent().parent().parent();
            var ptitle = $product.find(".name").text() +" "+$product.find(".subname").text();
            var text = $product.find(".text").text();
            var pimg = '';
            var bg = $product.find(".thirdbgproduct").css("background-image");
            if ( bg != undefined) {
                pimg = bg.replace('url("','').replace('")','');
            }
            var network = $(this).data("network");
            var url = "";
            switch (network) {
                case "facebook":
                    FB.ui({
                        method: 'feed',
                        name: ptitle,
                        link: purl,
                        picture: pimg,
                        caption: ptitle,
                        description: text,
                        message: ""
                    });
                    break;
                case "vkontakte":
                    url = 'http://vkontakte.ru/share.php?';
                    url += 'url=' + encodeURIComponent(purl);
                    url += '&title=' + encodeURIComponent(ptitle);
                    url += '&description=' + encodeURIComponent(text);
                    url += '&image=' + encodeURIComponent(pimg);
                    url += '&noparse=true';
                    social_open(url);
                    break;
                case "twitter":
                    url = 'https://twitter.com/intent/tweet?';
                    url += 'url=' + encodeURIComponent(purl);
                    url += '&text=' + encodeURIComponent(text);
                    url += '&hashtags=' + encodeURIComponent("TESS,"+ptitle);
                    social_open(url);
                    break;
            }
        };
        /*------------------------------------       news historija      ---------------------------------------------*/

        var makeVerticalPager = function ( $pagination, $pages ){
            if ( $pagination.length && $pages.length ) {
                $pages.filter( function (index) {
                    return ( index > 0 );
                }).hide();

                var $pagePointers = $("i", $pagination);
				if($pagePointers.length<=1){
					$pagePointers.css("display","none");
				}
                $pagePointers.each( function ( index ) {
                    var $pagePointer = $(this);
                    $pagePointer.on("click", function () {
                        if ( $pagePointer.hasClass("fa-circle-o") )
                        {
                            $pagePointers.removeClass("fa-circle").addClass("fa-circle-o");
                            $pagePointer.removeClass("fa-circle-o").addClass("fa-circle");

                            var hideDirection = "up";
                            var showDirection = "down";
                            if ( isEven(index) ) {
                                hideDirection = "down";
                                showDirection = "up";
                            }
                            $pages.hide("slide",{direction: hideDirection},800);
                            $pages.eq(index).show("slide",{direction: showDirection},800);
                        }
                    });
                });
            }
        };

        makeVerticalPager( $(".news-pagination"), $(".par-news") );
        makeVerticalPager( $(".historija-pagination"), $(".par-historija") );


        var hideProduct = function ($parent, callback, duration) {
            duration = parseInt(duration, 10) || 800;
            $parent.animate({opacity: 0}, {
                duration: duration,
                complete: function(){
                    $parent.hide();
                    $parent.css('opacity','1');
                    //console.warn("hide on "+$parent.prop("id"));
                    if ( typeof callback === "function" ) {
                        callback();
                    }
                }
            });
        };

        var productDetailLock = false;
        var releaseProductLock = function () {
            productDetailLock = false;
        };

        var closeProduct = function () {
            if ( !productDetailLock ) {
                productDetailLock = true;

                var $this = $(this);
                var $parent = $this.parent();
                var $section = $parent.closest(".totalhoverblockproducts");
                var $sliderWrapper = $(".whiteblockshadow", $section).parent();

                hideProduct($parent);
                $sliderWrapper.fadeIn({
                    duration: 800,
                    easing: "linear",
                    complete: releaseProductLock
                });

            }
        };

        var getProductById = function (id) {
            return $("#product-" + id );
        };

        var hideAndShowHandler = function ($current, $next) {
            var $cur = $current;
            var $n = $next;

            return function () {
                if ( !productDetailLock ) {
                    productDetailLock = true;
                    $cur.css("z-index", 10);
                    var releaseCallback = function () {
                        $cur.css("z-index", "auto");
                        releaseProductLock();
                    };

                    var $nextItem = getProductById($n.data("id"));
                    if ( $nextItem.length ) {
                        $nextItem.show();
                        //console.info("show called for " + $n.data("id") );
                        hideProduct($cur, releaseCallback, 600);

                    } else {
                        loadProduct( $n, function () {
                            var $p = getProductById($n.data("id"));
                            //console.info($p);
                            $p.show();
                            //console.info("show called for " + $n.data("id") );
                            hideProduct($cur ,releaseCallback, 600);
                        });
                    }
                }
            }
        };

        var bindProductArrows = function ($product, $previous, $next) {
            $(".previus", $product).on("click", hideAndShowHandler($product, $previous) );
            $(".next", $product).on("click", hideAndShowHandler($product, $next) );
        };

        /**
         * функция загружает товар, делает привязки обработчиков, вызывает опциональный колбэк
         * @param $element
         * @param callback
         */
        var loadProduct = function( $element, callback )
        {
            var id = $element.data("id");
            var ajaxUrl = "/ajax/product.php";
            if ( lang == "en" ) {
                ajaxUrl = "/en" + ajaxUrl;
            } else {
                ajaxUrl = "/ru" + ajaxUrl;
            }
            $.ajax({
                type: "POST",
                cache: false,
                url: ajaxUrl,
                dataType: "html",
                data: {id: id},
                statusCode: {
                    404: function () {
                        $element.off("click");
                    }
                },
                error: function () {
                    $element.off("click");
                },
                success: function (str) {
                    var $section = $element.closest(".totalhoverblockproducts");
                    $(".units", $section).append(str);
                    var $product = getProductById(id);
                    var $previous = $element.prev();
                    var $siblings = $element.siblings();
                    var $next = $element.next();

                    if ( $previous.length == 0 ) {
                        $previous = $siblings.last();
                    }

                    if ( $next.length == 0 ) {
                        $next = $siblings.first();
                    }
                    //console.info({prev: $previous.data("id"), next: $next.data("id")});
                    bindProductArrows( $product, $previous, $next );

                    $(".socialsharer", $product).find("a").on("click", socialShare);
                    $(".getback", $product).on("click", closeProduct);

                    if ( typeof callback === "function" ) {
                        callback();
                    }
                }
            });
        };

        /**
         * Функция показывает товар из списка
         * @param $product
         */
        var showProduct = function ( $product ) {
            var ofset = 18;
            if($(document).width()<1025){
                ofset = -18;
            }
            if ( isFF ) {
                ofset += 15;
            }

            var $section = $product.closest(".totalhoverblockproducts");
            var $sliderWrapper = $(".whiteblockshadow", $section).parent();
            /*
            console.info({
                bodyscrollTop: $("body").scrollTop(),
                htmlscrollTop: $("html").scrollTop(),
                ofset: ofset,
                newval: Math.round( $section.offset().top ) - ofset,
                section: $section[0]
            });
            */

            $('html, body').animate({
                scrollTop: Math.round( $section.offset().top ) - ofset
            }, 400,function(){
                $sliderWrapper.animate({opacity: 0}, 400 ,function(){
                    $sliderWrapper.hide();
                    $sliderWrapper.css('opacity','1');
                });
                $product.show("fade","linear",600,function(){
					permitedopen=true;
				});
            });
        };
		var permitedopen=true;
		var $productSliderList =  $(".products");
			$("li", $productSliderList).on("click", function () {
				if(permitedopen){
					permitedopen=false;
					if ( moveSliderLock ) {
						return false;
					}
					var $this = $(this);
					var $product = getProductById($this.data("id"));
					if ($product.length) {
						showProduct( $product);
					} else {
						loadProduct( $this, function () {
							showProduct( getProductById($this.data("id")) );
						});
					}
				}
			});


        /*---------------------------------------  верхнее меню ----------------------------------*/
        // работа выпадающего меню
        $(".menu-text").click(function(){
            //console.debug({clicked: this});
            // проверяем или кнопка уже была активирована
            var $this = $(this);
            var $parent = $this.parent();
            if( $parent.hasClass("active")){
                // если да то
                //деактивируем все кнопки на всякий
                $topListElem.removeClass("active");
                //$(this).parent().removeClass("active");

                //прячем нужный текст по айди спрятянном в элементе
                $("#"+$this.attr("for")).hide();

                //прячем белую полоску
                $(".subline").hide();
            }else{
                //если нет
                //убираем у всех активность на всякий

                if($this.hasClass("opening")){
                    $topListElem.removeClass("active");

                    //прячем все подменю
                    $(".listcontainer").hide();
                    //добавляем активность нужному
                    $parent.addClass("active");
                    //показываем нужное подменю
                    $("#"+$this.attr("for")).show();
                    //показываем полоску
                    $(".subline").show();
                }else{
                    var enlace  = $this.attr('href');
                    if ( enlace != undefined && enlace.indexOf("#") == 0  ) {
                        $topListElem.removeClass("active");

                        //прячем все подменю
                        $(".listcontainer").hide();
                        $(".subline").hide();
                        //добавляем активность нужному
                        $parent.addClass("active");
                        $(".animationblock").css("margin-top","0");
                        var scrollVal = $(enlace).offset().top;
                        if ( window.faceFix != undefined && $this.hasClass("anclaspan") && $(".face").offset().top >=0 ) {
                            scrollVal -=150;
                        }
                        //console.debug({anchor: $(enlace).offset().top, face: $(".face").offset().top} );
                        $('html, body').animate({
                            scrollTop: scrollVal
                        }, 2000,function(){
                            //console.debug({face2: $(".face").offset().top} );
                            $topListElem.removeClass("active");
                            //console.debug({face3: $(".face").offset().top} );
                        });
                    }
                }
            }
        });

        /*---------------------------------------  Слайдер продуктов ----------------------------------*/
        //двигается главный баннер, подается позиция на которую нужно перейти
        function movesbannersliderproduct1(meta) {

            //Достаем ширину
            var w = $(".porductslidercontainer").width();
            //вычисляем позицию слайдера
            var aux = "translate3d(-" + meta * w + "px, 0px, 0px)";
            //двигаем слайдер
            $("#productslider").css("transform", aux);
            //проводим манипуляции с точками, присваивая нужную выделеную позицию
            var $productcircle = $(".productcircle");
            $productcircle.removeClass("fa-circle").addClass("fa-circle-o");
            $productcircle.eq(meta).removeClass("fa-circle-o").addClass("fa-circle");
            //запоминаем позицию слайдера
            pos1 = meta;
        }

        function movesbannersliderproduct2(meta){

            //Достаем ширину
            var w = $(".porduct2slidercontainer").width();
            //вычисляем позицию слайдера
            var aux = "translate3d(-"+meta*w+"px, 0px, 0px)";
            //двигаем слайдер
            $("#product2slider").css("transform",aux);
            //проводим манипуляции с точками, присваивая нужную выделеную позицию
            var $productcircle = $(".product2circle");
            $productcircle.removeClass("fa-circle").addClass("fa-circle-o");
            $productcircle.eq(meta).removeClass("fa-circle-o").addClass("fa-circle");
            //запоминуем позицию слайдера
            pos2=meta;
        }

        function movesbannersliderproduct31(meta){

            //Достаем ширину
            var w = $(".porduct31slidercontainer").width();
            //вычисляем позицию слайдера
            var aux = "translate3d(-"+meta*w+"px, 0px, 0px)";
            //двигаем слайдер
            $("#product31slider").css("transform",aux);
            //проводим манипуляции с точками, присваивая нужную выделеную позицию

            var $circleList = $("i", $(".product31circles"));
            $circleList.removeClass("fa-circle").addClass("fa-circle-o");
            $circleList.eq(meta).removeClass("fa-circle-o").addClass("fa-circle");
            //запоминуем позицию слайдера
            pos31=meta;
        }
		
		function movesbannersliderproduct32(meta){

            //Достаем ширину
            var w = $(".porduct32slidercontainer").width();
            //вычисляем позицию слайдера
            var aux = "translate3d(-"+meta*w+"px, 0px, 0px)";
            //двигаем слайдер
            $("#product32slider").css("transform",aux);
            //проводим манипуляции с точками, присваивая нужную выделеную позицию

            var $circleList = $("i", $(".product32circles"));
			
            $circleList.removeClass("fa-circle").addClass("fa-circle-o");
            $circleList.eq(meta).removeClass("fa-circle-o").addClass("fa-circle");
            //запоминуем позицию слайдера
            pos32=meta;
        }

        function setTopSliderproduct1(){
            //var w = $(".porductslidercontainer").width();
            var w = $( window ).width()*0.865;
            var $slider = $("#productslider");
            if(w>767){
                maxpos1 = ($slider.children("li").length)/4-1;
                $slider.css("width",w*(maxpos1+1)+1);
                $slider.find("li").css("width",w/4);

            }else if(w<500){
                maxpos1 = ($slider.children("li").length)-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w);

            }else{
                maxpos1 = ($slider.children("li").length)/2-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w/2);
            }

            maxpos1 = Math.ceil(maxpos1);
            var pos1 = parseInt( $slider.closest(".whiteblockshadow").data("curpos"), 10 ) || 0;
            if(maxpos1<pos1){
                pos1=maxpos1;
            }
                movesbannersliderproduct1(pos1);
        }

        /*---------------------------------------  Слайдер пирамидок ----------------------------------*/

        //двигается главный баннер, подается позиция на которую нужно перейти

        function setTopSliderproduct2(){
            //var w = $(".porduct2slidercontainer").width();
            var w = $( window ).width()*0.844;

            var $slider = $("#product2slider");
            if(w>767){
                maxpos2 = ($slider.children("li").length)/4-1;
                $slider.css("width",w*(maxpos2+1)+1);
                $slider.find("li").css("width",w/4);

            }else if(w<500){

                maxpos2 = ($slider.children("li").length)-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w);

            }else{
                maxpos2 = ($slider.children("li").length)/2-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w/2);
            }


            maxpos2 = Math.ceil(maxpos2);
            var pos2 = parseInt( $slider.closest(".whiteblockshadow").data("curpos"), 10 ) || 0;
            if(maxpos2<pos2){
                pos2=maxpos2;
                movesbannersliderproduct2(pos2);
            }else{
                movesbannersliderproduct2(pos2);
            }
        }



        /*---------------------------------------  Слайдер пирамидок 31 ----------------------------------*/
        //двигается главный баннер, подается позиция на которую нужно перейти

        function setTopSliderproduct31(){
            //var w = $(".porduct31slidercontainer").width();
            var w = $( window ).width()*0.84;
            var $slider = $("#product31slider");
            /*$slider.css("width",w*(maxpos31+1));
             $slider.find("li").css("width",w/4);*/
            var $circles = $(".product31circles");
            var $previus = $("#product31previus");
            var $next = $("#product31next");
            if(w>767){
                var childrens = $slider.children("li").length;
                if(childrens>=4){
                    maxpos31 = (childrens)/4-1;
                    $slider.css("width",w*(maxpos2+1)+1);
                    $slider.find("li").css("width",w/4);
                }else{
                    $slider.find("li").css("width",100/childrens + "%");
                    $slider.css("width",w/4*childrens+1);
                    $slider.css("margin","auto");
                    maxpos31 = 0;
                    pos31 = 0;

                    $circles.css("display","none");
                    $previus.css("display","none");
                    $next.css("display","none");
                }

            }else if(w<500){
                $circles.css("display","block");
                $previus.css("display","block");
                $next.css("display","block");
                maxpos31 = ($slider.children("li").length)-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w);

            }else{
                $circles.css("display","block");
                $previus.css("display","block");
                $next.css("display","block");
                maxpos31 = ($slider.children("li").length)/2-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w/2);
            }
            maxpos31 = Math.ceil(maxpos31);
            if(maxpos31<=pos31){
                pos31=maxpos31;
                movesbannersliderproduct31(pos31);
            }else{
                movesbannersliderproduct31(pos31);
            }
        }
		
		/*---------------------------------------  Слайдер пирамидок 32 ----------------------------------*/
        //двигается главный баннер, подается позиция на которую нужно перейти

        function setTopSliderproduct32(){
            //var w = $(".porduct32slidercontainer").width();
            var w = $( window ).width()*0.84;
            var $slider = $("#product32slider");
            /*$slider.css("width",w*(maxpos32+1));
             $slider.find("li").css("width",w/4);*/
            var $circles = $(".product32circles");
            var $previus = $("#product32previus");
            var $next = $("#product32next");
            if(w>767){
                var childrens = $slider.children("li").length;
                if(childrens>=2){
                    maxpos32 = (childrens)/2-1;
                    $slider.css("width",w*(maxpos32+1)+1);
                    $slider.find("li").css("width",w/2);
                }else{
                    $slider.find("li").css("width",100/childrens + "%");
                    $slider.css("width",w/2*childrens+1);
                    $slider.css("margin","auto");
                    maxpos32 = 0;
                    pos32 = 0;

                    $circles.css("display","none");
                    $previus.css("display","none");
                    $next.css("display","none");
                }

            }else if(w<500){
                $circles.css("display","block");
                $previus.css("display","block");
                $next.css("display","block");
                maxpos32 = ($slider.children("li").length)-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w);

            }else{
                $circles.css("display","block");
                $previus.css("display","block");
                $next.css("display","block");
                maxpos32 = ($slider.children("li").length)/2-1;
                $slider.css("width",12000);
                $slider.find("li").css("width",w/2);
            }
            maxpos32 = Math.ceil(maxpos32);
            if(maxpos32<=pos32){
                pos32=maxpos32;
                movesbannersliderproduct32(pos32);
            }else{
                movesbannersliderproduct32(pos32);
            }
        }

        /*-----------------------------   Menu ---------------------------------------*/

        var menuSecondLinkHandler = function (e) {
            var enlace = $(this).attr('href');
            if ( enlace.indexOf("#") >=0 ) {
                e.preventDefault();
                $(".animationblock").css("margin-top", 0);
                hideAllTexts( $(enlace).offset().top ); // очень похоже на $("header").height()
            }
        };

        $menuSecondLinks.on("click", menuSecondLinkHandler);
    
    
        if ( window.location.hash.length ) {
           // nothing
        } else {
            window.faceFix = true;
            $animationblock.css("margin-top", "30px");
        }
        setTimeout( parallaxRun, 460 );
        // mobile menu
        $menuMobileLinks.click(function(e){
            var enlace  = $(this).attr('href');
            if ( enlace.indexOf("#") >=0 ) {
                e.preventDefault();
                $(".animationblock").css("margin-top","0");
                var ms = 2000;
                if ( window.pageYOffset == $(enlace).offset().top ) {
                    ms = 0;
                }
                $('html, body').animate({
                    scrollTop: $(enlace).offset().top
                }, ms,function(){
                    
                });
				$(".menu-list").hide('fold',{
                        direction: 'right'
                    },500);
            }
        });

    }; //tessmainPage

    if ( $body.hasClass("contact") ) {
        // работа меню
        $(".menu-text").click(function(){
            // проверяем или кнопка уже была активирована
            if($(this).parent().hasClass("active")){
                // если да то
                //деактивируем все кнопки на всякий
                $topListElem.removeClass("active");
                //$(this).parent().removeClass("active");

                //прячем белую полоску
                $(".subline").hide();
            }else{
                //если нет
                //убираем у всех активность на всякий

                if($(this).hasClass("opening")){
                    $topListElem.removeClass("active");
                    //добавляем активность нужному
                    $(this).parent().addClass("active");
                    //показываем нужное подменю
                    $("#"+$(this).attr("for")).show();
                    //показываем полоску
                    $(".subline").show();
                }else{
                    $topListElem.removeClass("active");

                    $(".subline").hide();
                    //добавляем активность нужному
                    $(this).parent().addClass("active");
                }
            }
        });
        parallaxRun();
    } else {
        tessMainPage();
    }

    SmoothScroll({
        frameRate        : 25, // [Hz]
        animationTime    : 300, // [ms]
        keyboardSupport: true,
        stepSize: 80,
        accelerationDelta : 0,
        accelerationMax   : 0,
        pulseAlgorithm   : false,
        pulseScale       : 1,
        pulseNormalize   : 1,
        touchpadSupport   : false
    });
/*
	var swiper = new Swiper('.swiper-container', {
		paginationClickable: true,
		nextButton:'#bannernext',
		prevButton:'#bannerprevius',
		loop:true,
		speed:1500,
		autoplay:10000,
		pagination:'.banercirslcescontainee',
		paginationType:'bullets',
		paginationHide:false,
		paginationBulletRender: function (swiper, currentClassName) {
			return '<i class="fa ' + currentClassName + '"></i>';
		},
		bulletClass:'fa-circle-o',
		bulletActiveClass:'fa-circle',
		simulateTouch:false
	});
*/
   
    
    var $subscribeForm = $(".footeremail");
    var subscribeShowErrorMessage = function () {
        $subscribeForm.replaceWith("<p class='footeremail'>"+$subscribeForm.data("error")+"</p>");
    };
    var subscribeShowSuccessMessage = function () {
        $subscribeForm.replaceWith("<p class='footeremail'>"+$subscribeForm.data("success")+"</p>");
    };
    
    var subscribeMarkInputError = function () {
        var $input = $("#subscribe-email");
        $input.css("border", "1px solid #ED2E24");
        $input.on("keyup", function () {
            $input.css("border", "none");
            $input.off("keyup");
        });
    };
    
    var footerFormLocked = false;
    $subscribeForm.on("submit", function () {
        if ( !footerFormLocked ) {
            footerFormLocked = true;
            var $input = $("#subscribe-email");
            var test = jQuery.trim( $input );
            if ( test.length < 6 ) {
                subscribeMarkInputError();
                footerFormLocked = false;
                return false;
            }
    
            var $form = $(this);
            
            $.ajax({
                type: "POST",
                cache: false,
                url: $form.prop("action"),
                dataType: "json",
                data: $form.serializeArray(),
                statusCode: {
                    404: function() {
                        subscribeShowErrorMessage();
                    }
                },
                error: function () {
                    subscribeShowErrorMessage();
                    console.info("error happens");
                    console.error( arguments );
                },
                success: function( data ) {
                    var isOk = true;
                    if ( jQuery.isPlainObject(data ) ) {
                        if (data.error != undefined && data.error.length ) {
                            isOk = false;
                            if (data.error == "email") {
                                subscribeMarkInputError();
                            } else {
                                subscribeShowErrorMessage();
                            }
                        } else {
                        }
                    } else {
                        subscribeShowErrorMessage();
                        isOk = false;
                    }
                    
                    if ( isOk ) {
                        subscribeShowSuccessMessage();
                    }
                    footerFormLocked = false;
                }
            })
    
        }
        return false;
    });

    var $feedbackWrapper = $(".contact-form");
    var $feedbackForm = $("form", $feedbackWrapper);
    $feedbackForm.on("submit", function () {
        $.ajax({
            type: "POST",
            cache: false,
            url: $feedbackForm.prop("action"),
            dataType: "json",
            data: $feedbackForm.serializeArray(),
            statusCode: {
                404: function() {
                    $feedbackForm.replaceWith("<p>internal error</p>");
                }
            },
            error: function () {
                console.error( arguments );
                $feedbackForm.replaceWith("<p>internal error</p>");
            },
            success: function( data ) {
                if ( data.errors != undefined && data.errors.length ) {
                    if ( data.sid != undefined ) {
                        $("input[name=cap_sid]", $feedbackForm).val(data.sid);
                        $(".captcha-img", $feedbackForm).attr("src", data.img_src);
                        $("#feedback-captcha", $feedbackForm).val("");
                    }
                    var err = data.errors;
                    var $errInput;
                    for ( var i=0; i < err.length; i++ ) {
                        $errInput = $("#" + err[i]);
                        $errInput.closest("li").addClass("errors");
                        $errInput.on("change", function () {
                            $(this).closest("li").removeClass("errors");
                        });
                        $errInput.on("keyup", function () {
                            var $t = $(this);
                            $t.closest("li").removeClass("errors");
                            $t.off("keyup");
                        });
                    }

                    console.info(data);
                } else {
                    $feedbackForm.replaceWith(data.html);
                }
            }
        });

        return false;
    });
    
window.fbAsyncInit = function() {
    FB.init({
      appId      : '329952207350107',
      xfbml      : true,
      version    : 'v2.7'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
});
$(window).load(function() {
		loadImage();
});

var queue = 1;
var isfontLoaded = false;
var isInit = false;
var isBgLoaded = false;


function loadImage(){
	if ( queue < 6){
		if (!isBgLoaded){
			if (document.location.pathname.indexOf('feedback') ==-1){
				$('body').css('backgroundImage', 'url(/local/templates/main/images/background.jpg)')
			}else{
					$('body').css({
					'backgroundImage': 'url(/local/templates/main/images/background.jpg)',
					'background-size' : 'cover'
					})
			}
			isBgLoaded = true;
		}
		var images = $("img[queue_"+queue+"]");
		if (images && images.size() > 0) {
			var img = $(images[0]).attr("current","");
			var i = new Image();
			i.onload = function(){
				var current = $($("img[current]")[0]);
				current.attr("src", current.attr("data-src")).removeAttr("current").removeAttr("queue_"+queue);
				loadImage();
			}
			i.src = img.attr("data-src");
			
		}else {
			if (queue == 2 && !isfontLoaded){
				isfontLoaded = true;
				$('head').append($('<link rel="stylesheet" type="text/css" />').attr('href', 'чай Tess. Чай в пирамидках. чай Тесс_files/font-awesome.min.css'));
			}
			if  (queue == 4 && !isInit){
				isInit = true;
			
				var swiper = new Swiper('.swiper-container', {
					paginationClickable: true,
					nextButton:'#bannernext',
					prevButton:'#bannerprevius',
					loop:true,
					speed:1500,
					autoplay:10000,
					pagination:'.banercirslcescontainee',
					paginationType:'bullets',
					paginationHide:false,
					paginationBulletRender: function (swiper, currentClassName) {
						return '<i class="fa ' + currentClassName + '"></i>';
					},
					bulletClass:'fa-circle-o',
					bulletActiveClass:'fa-circle',
					simulateTouch:false
				});
				
				 if ( swiper.on != undefined ) {
					swiper.on('slideChangeStart', function () {
					
						$.each( $( ".playerclass" ), function() {
							$(this)[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');
						});
					});
				}
				
			}
			if (queue == 5){
				
				$(".playerclass").each(function (i) {
					$(this).attr('src',$(this).attr('data-video-src'));
				});
			}else{
				queue++;
				loadImage();
			}
		}
	}
}