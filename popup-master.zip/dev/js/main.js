(function () {
  $.validator.addMethod(
    "emailWim",
    function (value, element) {
      // allow any non-whitespace characters as the host part
      return (
        this.optional(element) ||
        /(?:[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/.test(
          value
        )
      );
    },
    "Введите данные в указанном формате\nemail@exsample.comit"
  );

  function setCookieWim(cookie) {
    var options = {
      path: "/",
      secure: true,
      "max-age": 2678400,
    };
    cookie = cookie === 1 ? 1 : 3;
    if (!getCookieWim() || cookie === 1) {
      if (options.expires instanceof Date) {
        options.expires = options.expires.toUTCString();
      }
      let updatedCookie =
        encodeURIComponent("wim1") + "=" + encodeURIComponent(cookie);
      for (let optionKey in options) {
        updatedCookie += "; " + optionKey;
        let optionValue = options[optionKey];
        if (optionValue !== true) {
          updatedCookie += "=" + optionValue;
        }
      }
      document.cookie = updatedCookie;
      window.removeEventListener("mousemove", handler);
      window.removeEventListener("scroll", scrollWim);
      if (cookie !== 1) {
        $(".popup-right").css("display", "flex");
      }
    } else if (getCookieWim() > 1) {
      if (options.expires instanceof Date) {
        options.expires = options.expires.toUTCString();
      }
      let updatedCookie =
        encodeURIComponent("wim1") +
        "=" +
        encodeURIComponent(getCookieWim() - 1);
      for (let optionKey in options) {
        updatedCookie += "; " + optionKey;
        let optionValue = options[optionKey];
        if (optionValue !== true) {
          updatedCookie += "=" + optionValue;
        }
      }
      document.cookie = updatedCookie;
      window.removeEventListener("mousemove", handler);
      window.removeEventListener("scroll", scrollWim);
      $(".popup-right").css("display", "flex");
    } else {
      window.removeEventListener("mousemove", handler);
      window.removeEventListener("scroll", scrollWim);
    }
  }

  window.addEventListener("mousemove", handler);
  window.addEventListener("scroll", scrollWim);

  function getCookieWim() {
    let matches = document.cookie.match(
      new RegExp(
        "(?:^|; )" +
          "wim1".replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") +
          "=([^;]*)"
      )
    );
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  function handler() {
    if (window.event.clientY < 25 && getCookieWim() != 1) {
      setCookieWim();
    }
  }

  function scrollWim() {
    var scrollHeight = Math.max(
      document.body.scrollHeight,
      document.documentElement.scrollHeight,
      document.body.offsetHeight,
      document.documentElement.offsetHeight,
      document.body.clientHeight,
      document.documentElement.clientHeight
    );
    if (window.pageYOffset + screen.height / 2 >= scrollHeight / 2 -25 && window.pageYOffset + screen.height / 2 <= scrollHeight / 2 +25 ) {
      setCookieWim();
    }
  }

  $("#popup-sub-form").validate({
    errorElement: "span",
    errorPlacement: function (error, element) {
      error.appendTo(element.parent("div"));
    },
    ignore: ":disabled",
    rules: {
      email: {
        required: true,
        minlength: 5,
        emailWim: true,
      },
      testCheckbox: {
        required: true,
      },
    },
    messages: {
      testCheckbox: {
        required: "Вы должны принять соглашение",
      },
      email: {
        required: "Пожалуйста введите email",
        minlength: "Введите данные в указанном формате\nemail@exsample.com",
        emailWim: "Введите данные в указанном формате\nemail@exsample.com",
      },
    },
    submitHandler: function (e) {
      var data = {
        email: e.email.value,
      };
      $.ajax({
        type: "POST",
        url: "file.php",
        data: data,
        crossDomain: false,
        success: function () {
          $(".popup-right").css("display", "none");
          $(".after-right").css("display", "flex");
          setCookieWim(1);
        },
        error: function () {
          alert("Данные не ушли\nПовторите позже");
        },
      });
      e.submitButton.disabled = false;
    },
  });

  $(".close-btn").click(function () {
    $(".popup-right").css("display", "none");
  });

  $(".close-btn-after").click(function () {
    $(".after-right").css("display", "none");
  });
  window.onSubmit = function (token) {
    $("popup-submit-btn").disabled = true;
    $("#popup-sub-form").submit();
  };

})()